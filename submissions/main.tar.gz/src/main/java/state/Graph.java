package state;


import io.River;

import java.util.List;
import java.util.function.Predicate;

/**
 * A graph with nodes of type River and hence vertices of type int.
 */
public interface Graph {

    boolean containsVertex(int vertex);

    boolean containsEdge(River edge);

    Graph getSubGraph(Predicate<River> filter);

    List<Integer> getShortestPath(int source, int target);

    ArrayNatMap<Integer> getShortestPathLenghts(int source);




}
