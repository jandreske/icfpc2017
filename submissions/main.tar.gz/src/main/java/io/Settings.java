package io;

public class Settings {

    private boolean futures;

    private boolean splurges;

    private boolean options;

    public boolean isFutures() {
        return futures;
    }

    public void setFutures(boolean futures) {
        this.futures = futures;
    }

    public boolean isSplurges() {
        return splurges;
    }

    public void setSplurges(boolean splurges) {
        this.splurges = splurges;
    }

    public boolean isOptions() {
        return options;
    }

    public void setOptions(boolean options) {
        this.options = options;
    }
}
