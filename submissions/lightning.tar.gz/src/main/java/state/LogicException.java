package state;

public class LogicException extends RuntimeException {

    public LogicException(String message) {
        super(message);
    }

}
